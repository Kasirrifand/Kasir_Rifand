KASIR RIFAND AXSESORIS - CARA MEMASANG DI HP

Isi folder ini: index.html, manifest.json, sw.js, dan 3 ikon. Semua file harus diunggah bersama ke satu alamat web (HTTPS).

A. Unggah ke internet (pilih satu, gratis)
1) Netlify Drop (paling mudah, lewat laptop atau komputer)
   - Ekstrak file zip ini sampai jadi folder "kasir-rifand".
   - Buka app.netlify.com/drop, lalu seret folder tersebut ke halamannya.
   - Anda mendapat alamat seperti https://nama-acak.netlify.app. Alamat bisa diganti di Site settings.
2) GitHub Pages
   - Buat repositori publik, unggah semua file di folder ini, lalu aktifkan Settings > Pages.

B. Pasang di HP Android
   - Buka alamat tadi di Chrome.
   - Menu titik tiga > "Pasang aplikasi" (atau "Tambahkan ke layar utama").
   - Atau buka tab Toko di aplikasi dan tekan tombol "Pasang aplikasi".
   - Ikon "Kasir Rifand" muncul di layar utama. Setelah dibuka sekali, aplikasi tetap jalan tanpa internet.

C. Pindahkan data dari versi di Claude (bila sudah ada isinya)
   - Di versi lama: tab Toko > Unduh cadangan (JSON).
   - Di aplikasi baru: tab Toko > Pulihkan dari cadangan.
   Data tiap alamat web tersimpan terpisah, jadi tidak otomatis pindah.

Catatan
   - Data tersimpan di HP. Unduh cadangan secara berkala.
   - Scan kamera memakai kemiripan foto di HP. Tombol "Tanya AI Claude" hanya ada di versi dalam Claude.
   - Kamera dan pemasangan hanya bekerja lewat alamat HTTPS, bukan dengan membuka file langsung dari penyimpanan HP.
   - Untuk memperbarui aplikasi, unggah ulang folder dan ubah angka V di sw.js (misalnya kasir-rifand-v2).
